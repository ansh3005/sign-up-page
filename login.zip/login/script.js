document.getElementById('signupForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const email = document.getElementById('email').value;
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const message = document.getElementById('message');

    // Simple validation (replace with real signup logic in production)
    const confirmPassword = document.getElementById('confirmPassword').value;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasNumber = /[0-9]/.test(password);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

    if(email && username && password.length >= 8 && password === confirmPassword && hasUpperCase && hasNumber && hasSpecialChar) {
        message.style.color = 'green';
        message.textContent = 'Signup successful!';
    } else if (password !== confirmPassword) {
        message.style.color = 'red';
        message.textContent = 'Passwords do not match.';
    } else if (!hasUpperCase || !hasNumber || !hasSpecialChar) {
        message.style.color = 'red';
        message.textContent = 'Password must contain at least one uppercase letter, one number, and one special character.';
    } else {
        message.style.color = 'red';
        message.textContent = 'Please fill all fields and use a password with at least 8 characters.';
    }
});
